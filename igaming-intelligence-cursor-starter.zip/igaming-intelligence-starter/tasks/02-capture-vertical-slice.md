# Task 02 — Human capture vertical slice
Build minimum Chrome MV3 extension: explicit start/stop, per-site permissions, user-triggered screenshot, safe navigation event metadata, CSS inspection for selected visible elements, local preview and redact-before-upload workflow. Manual file import fallback. Backend ingests session -> artifacts -> journey steps. No collection of inputs, credentials, cookies, headers or payment information. No autonomous browsing.

Acceptance: on a permitted test site, capture three screens; review/redact; upload; render ordered journey with provenance; tests confirm sensitive fields excluded. Video and animation extraction can be separate follow-on.
