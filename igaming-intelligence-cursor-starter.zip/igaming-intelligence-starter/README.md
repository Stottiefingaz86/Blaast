# iGaming Intelligence — Cursor Starter

1. Put this folder alongside your existing `scuup` and `design-agent` repositories in one Cursor multi-root workspace.
2. Open `START_HERE_CURSOR.md` and paste its first instruction into Cursor Agent.
3. Run the read-only audit (`tasks/00-repository-audit.md`).
4. Review and approve reuse decisions before implementation.
5. Execute tasks 01–04 one at a time; update PRD/architecture after discoveries.

The 4-week integrated MVP is a planning target, not a commitment. This package does not contain the existing repositories or executable platform code.
